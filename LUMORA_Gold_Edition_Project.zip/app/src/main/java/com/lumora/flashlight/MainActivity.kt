package com.lumora.flashlight

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

private val Background = Color(0xFF080910)
private val Panel = Color(0xFF171827)
private val Purple = Color(0xFF9568FF)
private val Cyan = Color(0xFF62DDF3)
private val Gold = Color(0xFFD8B56D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LumoraApp() }
    }
}

@Composable
private fun LumoraApp() {
    var showSplash by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        delay(2200)
        showSplash = false
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Background,
            surface = Panel,
            primary = Purple,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        AnimatedVisibility(
            visible = showSplash,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            SplashScreen()
        }
        if (!showSplash) {
            FlashlightScreen()
        }
    }
}

@Composable
private fun SplashScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF19142A), Background, Color(0xFF05060B))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(112.dp)
                    .background(
                        Brush.radialGradient(
                            listOf(Purple.copy(alpha = 0.55f), Color.Transparent)
                        ),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.FlashlightOn,
                    contentDescription = null,
                    tint = Gold,
                    modifier = Modifier.size(66.dp)
                )
            }
            Spacer(Modifier.height(18.dp))
            Text(
                text = "LUMORA",
                color = Color.White,
                fontSize = 34.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 7.sp
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "LIGHT BEYOND LIMITS",
                color = Cyan,
                fontSize = 10.sp,
                letterSpacing = 3.sp
            )
            Spacer(Modifier.height(54.dp))
            Text(
                text = "A VISION BY",
                color = Color(0xFFB9B3A7),
                fontSize = 10.sp,
                letterSpacing = 3.sp
            )
            Spacer(Modifier.height(9.dp))
            Text(
                text = "محمد طارق",
                color = Gold,
                fontSize = 23.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(7.dp))
            Text(
                text = "صُنِعَ بشغف • Crafted with passion",
                color = Color(0xFF9D9587),
                fontSize = 11.sp,
                textAlign = TextAlign.Center
            )
        }
        Text(
            text = "LUMORA  •  VERSION 1.1",
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 28.dp),
            color = Color(0xFF777487),
            fontSize = 10.sp,
            letterSpacing = 1.5.sp
        )
    }
}

@Composable
private fun FlashlightScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val cameraManager = remember {
        context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    }

    var cameraId by remember { mutableStateOf<String?>(null) }
    var isOn by remember { mutableStateOf(false) }
    var maxStrength by remember { mutableIntStateOf(1) }
    var strength by remember { mutableFloatStateOf(1f) }
    var status by remember { mutableStateOf("جاري فحص إمكانيات جهازك...") }
    var error by remember { mutableStateOf<String?>(null) }

    fun switchOff() {
        val id = cameraId ?: return
        try {
            cameraManager.setTorchMode(id, false)
            isOn = false
            error = null
        } catch (_: Exception) {
            error = "تعذر إيقاف الفلاش. جرّب إغلاق تطبيق الكاميرا."
        }
    }

    fun switchOn(level: Int) {
        val id = cameraId ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && maxStrength > 1) {
                cameraManager.turnOnTorchWithStrengthLevel(id, level.coerceIn(1, maxStrength))
            } else {
                cameraManager.setTorchMode(id, true)
            }
            isOn = true
            error = null
        } catch (_: Exception) {
            error = "تعذر تشغيل الفلاش. قد يكون مشغولاً بتطبيق آخر."
            isOn = false
        }
    }

    LaunchedEffect(cameraManager) {
        try {
            val availableId = cameraManager.cameraIdList.firstOrNull { id ->
                val characteristics = cameraManager.getCameraCharacteristics(id)
                characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    (characteristics.get(CameraCharacteristics.LENS_FACING) ==
                        CameraCharacteristics.LENS_FACING_BACK)
            } ?: cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }

            cameraId = availableId
            if (availableId == null) {
                status = "هذا الجهاز لا يحتوي على فلاش متاح"
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    val characteristics = cameraManager.getCameraCharacteristics(availableId)
                    maxStrength = characteristics.get(
                        CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL
                    ) ?: 1
                }
                strength = maxStrength.toFloat()
                status = if (maxStrength > 1) {
                    "جهازك يدعم التحكم في قوة الإضاءة"
                } else {
                    "جهازك يدعم التشغيل والإيقاف فقط"
                }
            }
        } catch (_: Exception) {
            status = "لم نتمكن من قراءة إمكانيات الفلاش"
        }
    }

    DisposableEffect(cameraManager) {
        val callback = object : CameraManager.TorchCallback() {
            override fun onTorchModeChanged(id: String, enabled: Boolean) {
                if (id == cameraId) isOn = enabled
            }

            override fun onTorchModeUnavailable(id: String) {
                if (id == cameraId) {
                    isOn = false
                    error = "الفلاش مشغول حالياً بتطبيق آخر."
                }
            }
        }
        cameraManager.registerTorchCallback(callback, null)
        onDispose {
            try {
                cameraManager.unregisterTorchCallback(callback)
            } catch (_: Exception) {
                // Ignore callback cleanup errors.
            }
            try {
                cameraId?.let { cameraManager.setTorchMode(it, false) }
            } catch (_: Exception) {
                // The camera may already be unavailable.
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            if (isOn) switchOff() else switchOn(strength.toInt().coerceAtLeast(1))
        } else {
            error = "اسمح بإذن الكاميرا للتحكم في فلاش الهاتف."
        }
    }

    fun toggleFlash() {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        } else if (isOn) {
            switchOff()
        } else {
            switchOn(strength.toInt().coerceAtLeast(1))
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF17142A), Background, Color(0xFF05060B))
                )
            )
            .padding(horizontal = 22.dp, vertical = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "LUMORA",
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 6.sp
            )
            Text(
                "LIGHT BEYOND LIMITS",
                color = Cyan,
                fontSize = 10.sp,
                letterSpacing = 2.5.sp
            )
            Spacer(Modifier.height(42.dp))

            Box(
                modifier = Modifier
                    .size(214.dp)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                if (isOn) Purple.copy(alpha = 0.42f)
                                else Color(0xFF302A49),
                                Color.Transparent
                            )
                        ),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                FilledIconButton(
                    onClick = { toggleFlash() },
                    modifier = Modifier.size(142.dp),
                    shape = CircleShape,
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = if (isOn) Purple else Color(0xFF292A3E),
                        contentColor = Color.White
                    )
                ) {
                    Icon(
                        imageVector = if (isOn) Icons.Filled.FlashlightOn
                        else Icons.Filled.FlashlightOff,
                        contentDescription = if (isOn) "إيقاف الفلاش" else "تشغيل الفلاش",
                        modifier = Modifier.size(62.dp)
                    )
                }
            }

            Spacer(Modifier.height(22.dp))
            Text(
                if (isOn) "الفلاش يعمل" else "الفلاش متوقف",
                color = if (isOn) Cyan else Color.LightGray,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )
            Spacer(Modifier.height(28.dp))

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                color = Panel.copy(alpha = 0.94f)
            ) {
                Column(Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "قوة الإضاءة",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.weight(1f))
                        Text(
                            if (maxStrength > 1) {
                                "${(strength / maxStrength * 100).toInt()}%"
                            } else {
                                "غير مدعوم"
                            },
                            color = Cyan,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Slider(
                        value = strength,
                        onValueChange = { strength = it },
                        onValueChangeFinished = {
                            if (isOn && maxStrength > 1) {
                                switchOn(strength.toInt().coerceIn(1, maxStrength))
                            }
                        },
                        valueRange = 1f..maxStrength.coerceAtLeast(2).toFloat(),
                        enabled = maxStrength > 1,
                        colors = SliderDefaults.colors(
                            thumbColor = Cyan,
                            activeTrackColor = Purple,
                            inactiveTrackColor = Color(0xFF414154)
                        )
                    )
                    Text(
                        if (maxStrength > 1) {
                            "اسحب المؤشر لتغيير شدة الفلاش"
                        } else {
                            "التحكم في الشدة غير متاح على هذا الهاتف"
                        },
                        color = Color(0xFFAAAABD),
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(Modifier.height(18.dp))
            Text(
                status,
                color = Color(0xFFB8B7C8),
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
            error?.let {
                Spacer(Modifier.height(8.dp))
                Text(
                    it,
                    color = Color(0xFFFF9B9B),
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
            }
        }

        Text(
            "صُنِعَ بشغف • محمد طارق",
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 8.dp),
            color = Gold,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
