# LUMORA — Gold Edition

An Android flashlight app built with Kotlin and Jetpack Compose.

## Branding
The opening screen displays:
- LUMORA
- LIGHT BEYOND LIMITS
- A VISION BY
- محمد طارق (gold typography)
- صُنِعَ بشغف • Crafted with passion

## Features
- Flashlight on/off using Android CameraManager.
- Detects a flash-equipped camera automatically, preferring the rear camera.
- Reads the maximum torch strength on Android 13+.
- Enables the brightness slider only if the phone reports more than one torch strength level.
- Falls back to normal on/off control on phones without variable torch strength.
- Dark premium interface with purple lighting and gold creator credit.

## Build APK from a phone using GitHub Actions
1. Create a GitHub repository named `LUMORA`.
2. Upload the *contents* of this ZIP into the repository, preserving folders and the `.github` folder.
3. Open the repository's Actions tab.
4. Select **Build LUMORA APK** and tap **Run workflow** (or let the push trigger it).
5. When the run succeeds, open it and download the **LUMORA-APK** artifact.
6. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.

## Compatibility
The Android torch-strength API is available from Android 13 (API 33), but the phone's camera hardware/driver must expose multiple strength levels. No app can force variable flash power on hardware that only supports on/off. Android CAMERA permission is requested because Android gates torch control through camera APIs.

## Project settings
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- Kotlin: 2.0.21
- Compile SDK: 35
- Target SDK: 34
- Minimum SDK: 23
